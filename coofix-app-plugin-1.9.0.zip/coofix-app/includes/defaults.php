<?php
if (!defined('ABSPATH')) {
    exit;
}

/** Icon keys the app understands (key => Arabic label). */
function coofix_app_icons() {
    return array(
        'auto'         => 'تلقائي',
        'battery'      => 'بطارية',
        'bolt'         => 'كهرباء',
        'fuel'         => 'وقود',
        'air'          => 'هواء',
        'handyman'     => 'عدة يدوية',
        'extension'    => 'إكسسوارات',
        'construction' => 'إنشاءات',
        'build'        => 'صيانة',
        'shield'       => 'درع / كفالة',
        'verified'     => 'موثّق / أصلي',
        'handshake'    => 'مصافحة / تجار',
        'truck'        => 'توصيل',
        'storefront'   => 'متجر',
        'support'      => 'دعم فني',
        'star'         => 'نجمة',
        'percent'      => 'خصم',
        'gift'         => 'هدية',
        'flash'        => 'عرض سريع',
        'garden'       => 'حدائق',
        'paint'        => 'دهان',
        'water'        => 'مياه',
        'measure'      => 'قياس',
        'safety'       => 'سلامة',
        'home'         => 'منزل',
        'phone'        => 'هاتف',
        'chat'         => 'محادثة',
        'clock'        => 'وقت',
        'location'     => 'موقع',
        'info'         => 'معلومات',
    );
}

/** Where a tap on a banner / announcement / popup leads. */
function coofix_app_actions() {
    return array(
        'none'      => 'بدون',
        'category'  => 'فتح قسم (رقم القسم)',
        'product'   => 'فتح منتج (رقم المنتج)',
        'search'    => 'بحث (كلمة البحث)',
        'tab'       => 'تبويب (home / categories / cart / favorites / more)',
        'whatsapp'  => 'واتساب (نص الرسالة)',
        'phone'     => 'اتصال (الرقم)',
        'url'       => 'رابط خارجي',
        'page'      => 'صفحة داخلية (about / warranty / maintenance)',
    );
}

/** Home sections the app can render (key => default title). */
function coofix_app_section_keys() {
    return array(
        'announcement' => 'شريط الإعلان',
        'hero'         => 'البانرات المتحركة',
        'categories'   => 'تسوّق حسب القسم',
        'deals'        => 'عروض حصرية',
        'values'       => 'مميزات كوفيكس',
        'latest'       => 'وصل حديثاً',
        'featured'     => 'الأكثر طلباً',
        'maintenance'  => 'بانر الصيانة',
    );
}

function coofix_app_defaults() {
    return array(
        'meta' => array('updated' => 0),

        'general' => array(
            'app_name'      => 'كوفيكس سوريا',
            'tagline'       => 'الوكيل الحصري والرسمي في سوريا',
            'welcome_small' => 'أهلاً بك في',
            'welcome_big'   => 'كوفيكس سوريا',
            'search_hint'   => 'ابحث عن مثقب، جلاخة، كمبريسور...',
            'maintenance'   => array(
                'enabled' => false,
                'title'   => 'التطبيق قيد التحديث',
                'message' => 'نعمل على تحسين تجربتك، سنعود خلال وقت قصير. يمكنك التواصل معنا عبر واتساب.',
            ),
            'update'        => array(
                'min_version'    => '1.0.0',
                'latest_version' => '1.0.0',
                'force'          => false,
                'title'          => 'تحديث جديد متوفر',
                'message'        => 'نسخة جديدة من التطبيق بميزات وتحسينات جديدة.',
                'android_url'    => '',
                'ios_url'        => '',
            ),
        ),

        'brand' => array(
            'primary'       => '#FAA21B',
            'primary_light' => '#FFC14F',
            'primary_deep'  => '#E08A00',
            'dark'          => '#061922',
            'dark_light'    => '#0F3041',
            'background'    => '#F4F3F0',
            'text'          => '#15181D',
            'logo_url'      => '',
            'icon_url'      => '',
            'splash_title'  => 'COOFIX',
            'splash_sub'    => 'كوفيكس سوريا',
            'splash_note'   => 'الوكيل الحصري والرسمي في سوريا',
            'splash_seconds'=> 2.6,
            'corner_radius' => 24,
        ),

        'announcement' => array(
            'enabled'      => false,
            'text'         => '🔥 خصومات حتى 20% على عدد البطارية',
            'bg'           => '#061922',
            'fg'           => '#FFFFFF',
            'action_type'  => 'none',
            'action_value' => '',
        ),

        'popup' => array(
            'enabled'      => false,
            'id'           => 'welcome-1',
            'title'        => 'أهلاً بك في تطبيق كوفيكس',
            'body'         => 'تصفّح العدد الأصلية واطلب مباشرة عبر واتساب.',
            'image'        => '',
            'button'       => 'تسوّق الآن',
            'action_type'  => 'tab',
            'action_value' => 'categories',
            'every_launch' => false,
        ),

        'banners' => array(
            array('enabled' => true, 'image' => '', 'style' => 'dark',   'icon' => 'bolt',       'kicker' => 'الوكيل الحصري',  'title' => "قوة احترافية\nبين يديك",        'subtitle' => 'عدد كوفيكس الأصلية بكفالة 6 أشهر', 'cta' => 'تسوّق الآن',     'action_type' => 'tab',      'action_value' => 'categories'),
            array('enabled' => true, 'image' => '', 'style' => 'accent', 'icon' => 'battery',    'kicker' => 'حرية بلا أسلاك', 'title' => "عدد البطارية\nبتقنية الليثيوم", 'subtitle' => 'منصة 20V واحدة لكل عدتك',         'cta' => 'اكتشف التشكيلة', 'action_type' => 'search',   'action_value' => 'شحن'),
            array('enabled' => true, 'image' => '', 'style' => 'dark2',  'icon' => 'storefront', 'kicker' => 'للتجار والورش',  'title' => "أسعار خاصة\nلطلبات الجملة",     'subtitle' => 'تواصل مع فريق المبيعات مباشرة',   'cta' => 'راسلنا واتساب',  'action_type' => 'whatsapp', 'action_value' => 'مرحباً، أرغب بالاستفسار عن أسعار الجملة للتجار.'),
        ),
        'banner_seconds' => 5,
        'banner_height'  => 196,

        'home' => array(
            'sections' => array(
                array('key' => 'announcement', 'enabled' => true, 'title' => '',                 'subtitle' => ''),
                array('key' => 'hero',         'enabled' => true, 'title' => '',                 'subtitle' => ''),
                array('key' => 'categories',   'enabled' => true, 'title' => 'تسوّق حسب القسم', 'subtitle' => ''),
                array('key' => 'deals',        'enabled' => true, 'title' => 'عروض حصرية',       'subtitle' => 'خصومات لفترة محدودة'),
                array('key' => 'values',       'enabled' => true, 'title' => '',                 'subtitle' => ''),
                array('key' => 'latest',       'enabled' => false,'title' => 'وصل حديثاً',       'subtitle' => 'أحدث المنتجات في المتجر'),
                array('key' => 'featured',     'enabled' => true, 'title' => 'الأكثر طلباً',     'subtitle' => 'اختيارات المحترفين في الورش'),
                array('key' => 'maintenance',  'enabled' => true, 'title' => 'مركز الصيانة المعتمد', 'subtitle' => 'تابع حالة عدّتك برقم الطلب أو الهاتف'),
            ),
        ),

        'categories' => array(
            'order'  => array(),
            'hidden' => array(),
            'icons'  => array(),
            'names'  => array(),
            'dark_every' => 3,
        ),

        'products' => array(
            'use_demo'          => true,
            'min_catalogue'     => 8,
            'featured_mode'     => 'featured',
            'featured_ids'      => array(),
            'featured_count'    => 8,
            'latest_count'      => 8,
            'show_out_of_stock' => true,
            'hide_prices'       => false,
            'hidden_price_text' => 'اطلب السعر',
            'currency_label'    => '',
            'show_old_price'    => true,
            'show_discount'     => true,
            'show_sku'          => true,
            'show_specs'        => true,
            'show_related'      => true,
            'parse_specs_from_description' => true,
            'allow_cart'        => true,
            'perks'             => array(
                array('icon' => 'shield',   'title' => 'كفالة',  'sub' => '6 أشهر'),
                array('icon' => 'verified', 'title' => 'أصلي',   'sub' => '100%'),
                array('icon' => 'truck',    'title' => 'توصيل',  'sub' => 'لكل المحافظات'),
            ),
            'ask_text' => 'عندك سؤال؟ اسأل خبير كوفيكس على واتساب',
        ),

        'contact' => array(
            'whatsapp_orders'      => '963955791888',
            'whatsapp_support'     => '963955791888',
            'whatsapp_maintenance' => '963955791888',
            'phone'                => '963955791888',
            'email'                => '',
            'website'              => 'https://www.coofix.sy',
            'catalogue_url'        => 'https://www.coofix.sy',
            'address'              => '',
            'maps_url'             => '',
            'hours'                => '',
            'socials'              => array(
                'facebook'  => '',
                'instagram' => '',
                'tiktok'    => '',
                'telegram'  => '',
                'youtube'   => '',
            ),
        ),

        'order' => array(
            'button'        => 'اطلب عبر واتساب',
            'sheet_title'   => 'إتمام الطلب',
            'sheet_note'    => 'سيتم إرسال طلبك إلى فريق كوفيكس على واتساب لتأكيده.',
            'header'        => "مرحباً كوفيكس سوريا 👋\nأرغب بطلب المنتجات التالية من التطبيق:",
            'footer'        => 'شكراً لكم.',
            'show_total'    => true,
            'total_label'   => 'الإجمالي التقريبي',
            'ask_name'      => true,
            'ask_city'      => true,
            'ask_phone'     => false,
            'ask_note'      => true,
            'require_name'  => false,
            'require_city'  => false,
            'require_phone' => false,
        ),

        'pages' => array(
            'values' => array(
                array('icon' => 'verified',  'title' => 'جودة أصلية',    'sub' => 'منتجات معتمدة من الشركة الأم'),
                array('icon' => 'shield',    'title' => 'كفالة 6 أشهر',  'sub' => 'صيانة وقطع غيار مضمونة'),
                array('icon' => 'handshake', 'title' => 'نرحّب بالتجار', 'sub' => 'أسعار جملة وشراكات'),
            ),
            'about_title' => 'من نحن',
            'about_body'  => "كوفيكس سوريا هي الوكيل الحصري والرسمي لعلامة كوفيكس في سوريا. نوفّر تشكيلة متكاملة من العدد الكهربائية وعدد البطارية والوقود والهواء والعدد اليدوية مع كفالة حقيقية ومركز صيانة معتمد وقطع غيار أصلية.\n\nنرحّب بالتجار والموزعين في جميع المحافظات، ونقدّم أسعاراً خاصة للجملة.",
            'warranty_title'  => 'كفالة 6 أشهر',
            'warranty_points' => array(
                array('title' => 'مدة الكفالة', 'body' => 'ستة أشهر من تاريخ الشراء على جميع عدد كوفيكس الأصلية.'),
                array('title' => 'ما تشمله',    'body' => 'عيوب التصنيع والأعطال الفنية الناتجة عن الاستخدام الطبيعي.'),
                array('title' => 'ما لا تشمله', 'body' => 'سوء الاستخدام، الكسر، والقطع الاستهلاكية كالفحمات والشفرات.'),
                array('title' => 'كيف تستفيد',  'body' => 'احتفظ بفاتورة الشراء وتواصل مع مركز الصيانة عبر التطبيق.'),
            ),
            'maintenance_title' => 'تتبّع الصيانة',
            'maintenance_intro' => 'أدخل رقم طلب الصيانة (CFX-…) أو رقم هاتفك المسجّل عند تسليم العدّة.',
            'trader_message'    => 'مرحباً، أنا تاجر وأرغب بالاستفسار عن أسعار الجملة لدى كوفيكس سوريا.',
            'search_suggestions'=> array('مثقب', 'جلاخة', 'شحن', 'كمبريسور', 'منشار', 'مولدة', 'طقم'),
            'stats_products_label' => 'منتج',
            'footer_note'       => '',
            'more_items'        => array(
                'maintenance' => true,
                'warranty'    => true,
                'catalogue'   => false,
                'traders'     => true,
                'whatsapp'    => true,
                'call'        => true,
                'website'     => true,
                'email'       => true,
                'location'    => true,
                'socials'     => true,
                'about'       => true,
            ),
        ),

        'site' => array(
            'enabled'    => true,
            'app_home'   => true,
            'bottom_nav' => true,
        ),

        'nav' => array(
            'home'       => 'الرئيسية',
            'categories' => 'الأقسام',
            'cart'       => 'السلة',
            'favorites'  => 'المفضلة',
            'more'       => 'المزيد',
            'show_favorites' => true,
        ),
    );
}
